#SimpleJavaCalculator

Originally this project was written using Eclipse, but I have migrated it to NetBeans.
This calculator is simple with an easy code to help novices learn how to operate a calculator.

If you use the executable file "calculator.jar" and that it does not run, you can type "java -jar /your_calculator_directory/calculator.jar" in your terminal.


![Example: Java Calculator](Screenshots/screenshot.png)

##AUTHOR

###Base Application

Pierre-Henry SORIA

###Modifications and Improvements

Achintha Gunasekara

http://www.achinthagunasekara.com

##CONTACT

Pierre-Henry SORIA: pierrehs@hotmail.com

Achintha Gunasekara: contact@achinthagunasekara.com

##LICENSE

Apache License, Version 2.0 or later; See the license.txt file in the "NotePad" folder.
